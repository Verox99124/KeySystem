import os
import subprocess
import time
import sys
import threading

os.system("")

# Fixed & Enhanced SPAMMERV2 ASCII Art
ascii_art = """
\033[38;5;196m███████╗\033[38;5;202m██████╗ \033[38;5;208m █████╗\033[38;5;214m ███╗   ███╗\033[38;5;220m███╗   ███╗\033[38;5;226m███████╗\033[38;5;118m██████╗ 
\033[38;5;196m██╔════╝\033[38;5;202m██╔══██╗\033[38;5;208m██╔══██╗\033[38;5;214m████╗ ████║\033[38;5;220m████╗ ████║\033[38;5;226m██╔════╝\033[38;5;118m██╔══██╗
\033[38;5;196m███████╗\033[38;5;202m██████╔╝\033[38;5;208m███████║\033[38;5;214m██╔████╔██║\033[38;5;220m██╔████╔██║\033[38;5;226m█████╗  \033[38;5;118m██████╔╝
\033[38;5;196m╚════██║\033[38;5;202m██╔═══╝ \033[38;5;208m██╔══██║\033[38;5;214m██║╚██╔╝██║\033[38;5;220m██║╚██╔╝██║\033[38;5;226m██╔══╝  \033[38;5;118m██╔══██╗
\033[38;5;196m███████║\033[38;5;202m██║     \033[38;5;208m██║  ██║\033[38;5;214m██║ ╚═╝ ██║\033[38;5;220m██║ ╚═╝ ██║\033[38;5;226m███████╗\033[38;5;118m██║  ██║
\033[38;5;196m╚══════╝\033[38;5;202m╚═╝     \033[38;5;208m╚═╝  ╚═╝\033[38;5;214m╚═╝     ╚═╝\033[38;5;220m╚═╝     ╚═╝\033[38;5;226m╚══════╝\033[38;5;118m╚═╝  ╚═╝
\033[38;5;45m   ██╗   ██╗\033[38;5;87m▓▓▓▓
\033[38;5;45m   ╚═╝   ╚═╝\033[38;5;87m▓▓▓▓
"""

# Global variables for spam control
spamming = False
stop_spam = False

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def show_menu():
    clear_screen()
    print("\033[38;5;33m" + "="*50)
    print(ascii_art)
    print("\033[38;5;33m" + "="*50)
    print("\033[38;5;46m1. Webhook Spammer")
    print("\033[38;5;46m2. Stop Webhook Spam")
    print("\033[38;5;46m3. Delete Webhook")
    print("\033[38;5;196m4. Exit")
    print("\033[38;5;33m" + "="*50)
    choice = input("\033[38;5;214mSelect an option (1-4): ")
    return choice

def spam_webhook(webhook_url, message, delay):
    global spamming, stop_spam
    spamming = True
    stop_spam = False
    
    try:
        while not stop_spam:
            curl_command = f'curl -X POST -H "Content-Type: application/json" -d "{{\\"content\\": \\"{message}\\"}}" {webhook_url}'
            subprocess.run(curl_command, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f"\033[38;2;143;25;25mMessa\033[38;5;226mge send\033[38;5;214ming with \033[38;5;226m{delay} de\033[38;2;204;51;51mlay.")
            time.sleep(delay)
    except KeyboardInterrupt:
        pass
    finally:
        spamming = False
        stop_spam = False

def webhook_spammer():
    global spamming
    
    if spamming:
        print("\033[38;5;196mSpam is already running! Stop it first.")
        time.sleep(1)
        return
        
    clear_screen()
    print(ascii_art)
    print("\033[38;5;33m" + "="*50)
    message = input("\033[38;5;214mEnter the message to send: ")
    webhook_url = input("\033[38;5;214mEnter your Discord webhook URL: ")
    delay = float(input("\033[38;5;214mEnter delay (in seconds): "))
    
    # Start spamming in a new thread
    spam_thread = threading.Thread(target=spam_webhook, args=(webhook_url, message, delay))
    spam_thread.daemon = True
    spam_thread.start()
    
    print("\033[38;5;46mSpamming started! Press Ctrl+C in this menu to stop or use option 2.")
    input("\033[38;5;214mPress Enter to return to menu...")

def stop_webhook_spam():
    global stop_spam, spamming
    
    if not spamming:
        print("\033[38;5;196mNo active spam to stop!")
    else:
        stop_spam = True
        print("\033[38;5;46mStopping spam... Please wait for current messages to finish.")
    
    time.sleep(1)

def delete_webhook():
    clear_screen()
    print(ascii_art)
    print("\033[38;5;33m" + "="*50)
    webhook_url = input("\033[38;5;214mEnter the Discord webhook URL to delete: ")
    
    try:
        # Discord API requires DELETE method to delete webhook
        curl_command = f'curl -X DELETE {webhook_url}'
        result = subprocess.run(curl_command, shell=True, capture_output=True, text=True)
        
        if result.returncode == 0:
            print("\033[38;5;46mWebhook deleted successfully!")
        else:
            print("\033[38;5;196mFailed to delete webhook. It may already be deleted or the URL is invalid.")
    except Exception as e:
        print(f"\033[38;5;196mError occurred: {e}")
    
    time.sleep(2)

def main():
    while True:
        choice = show_menu()
        
        if choice == "1":
            webhook_spammer()
        elif choice == "2":
            stop_webhook_spam()
        elif choice == "3":
            delete_webhook()
        elif choice == "4":
            clear_screen()
            print(ascii_art)
            print("\033[38;5;196mExiting SPAMMERV2... Goodbye!")
            time.sleep(1)
            sys.exit()
        else:
            print("\033[38;5;196mInvalid option! Please choose between 1-4.")
            time.sleep(1)

if __name__ == "__main__":
    main()
